<!DOCTYPE html>
<html lang="en">
<head>
<meta charset = "UTF-8">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<title> All Products - IoT Store </title>
<link rel="stylesheet" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<?php
    include("connection.php");
    session_start();
    if(!isset($_SESSION['user'])){
            header('Location:index.php');
    }
    $userId=$_SESSION['user']['Customer_id'];

        // print_r($_SESSION['user']); die();
        $select = mysqli_query($conn, "SELECT cart.*,product.Product_Name,product.Product_Price,product.Product_Image FROM cart INNER JOIN product ON cart.product_id=product.Product_id where user_id=$userId");
        $cart=mysqli_fetch_all($select,MYSQLI_ASSOC);

    if(isset($_POST['submit'])){
        // print_r($_POST); die();
        
        $Order_No=rand(10000,99999);
        $phone=$_POST['phone'];
        $delivery_address=$_POST['delivery_address'];
        $total=$_POST['total'];
        
        $sql=mysqli_query($conn,"INSERT INTO `orders`(`Order_No`, `Order_Total`,  `phone`, `delivery_address`, `Customer_id`) 
        VALUES ('$Order_No','$total','$phone','$delivery_address','$userId')");
            if($sql){
                $orderId=mysqli_insert_id($conn);
                foreach ($cart as $value) {
                    $total=$value['Product_Price']*$value['quantity'];
                    $item=mysqli_query($conn,"INSERT INTO `order_items`(`Order_id`, `Product_id`,  `Product_Quantity`, `Product_Price`, `Subtotal`) 
                    VALUES ('$orderId','$value[product_id]','$value[quantity]','$value[Product_Price]','$total')");
                }

                $sql=mysqli_query($conn,"DELETE FROM `cart` WHERE `user_id`=$userId");
            }
            echo '<script>
            window.location.href ="orders.php";
            alert("Order Placed Successful!")
            </script>';

    }
 
 
    // print_r($cart); die();
   
?>
<body>
<div class="header">


<div class ="container">
<div class ="navbar">
<div class ="logo">
<img src="images/Iot_logo.png" width="100px">

</div>

<nav>
<ul>

<li><a href="index.php">Home</a></li>
<li><a href="products.php">Products</a></li>
<li><a href="AboutUs.php">About</a></li>
<li><a href="contact.php">Contact</a></li>
 <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>

</ul>
</nav>
    <a href="cart.php"><img src="images/shoppingbag.png" width="30px" height="30px"></a>


</div>


</div>
</div>
<br>

    <!--- cart item details ---->
    
    <div class="small-container cart-page">
        <div class="row">
            <div class="col-md-8">
                <h2>Complete Your Info and Confirm Order</h2> <br>
                <form action="checkout.php" method="post">
                <label for="">Your Name</label>
                <input type="text" name="name" required class="form-control" id=""> <br>
                <label for="">Phone Number</label>
                <input type="text" name="phone" required class="form-control" id=""> <br>
                <label for="">Delivery Address</label>
                <input type="text" required name="delivery_address" class="form-control" id="">
                
                <button type="submit" name="submit" class="btn primary" style="float:right">Confirm Order</a>
            </div>
            <div class="col-md-4">
                <table>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                    </tr>
                    <?php $total=0;
                    foreach ($cart as $value) { $total+=$value['Product_Price']; ?>
                    <tr>
                        <td>
                        <div class="cart-info">
                            <img src="uploaded_img/<?=$value['Product_Image']?>"width="22%">
                            <div>
                                <p><?=$value['Product_Name']?></p>
                                <small>Price: <?=$value['Product_Price']?> SAR</small>
                                <br>
                                <a  href="cart.php?remove=1&cartId=<?=$value['id']?>">Remove</a>
                            </div>
                            </div>

                        </td>
                        <td> <?=$value['quantity']?></td>

                        <td><?=$value['Product_Price']*$value['quantity']?> SAR</td>
                    </tr>
                    <?php }?>
                
                </table>
                
                <div class="total-price" style="display:block">
                    <table style="max-width:500px">
                        <tr>
                            <td>Subtotal</td>
                            <td><?=$total?> SAR</td>
                        </tr>
                        <tr>
                            <td>Tax</td>
                            <td><?=$tax=$total*2/100?> SAR</td>
                        </tr>
                        <tr>
                            <td>Total</td>
                            <td><?=$tax+$total?> SAR</td>
                        </tr>

                    </table>
                    <input type="hidden" name="total" value="<?=$tax+$total?>">

                </form>

                </div>
            </div>
        </div>
       
        
    </div>
    
    
<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->

</ul>
</div>


</div></div>


    

</body>
</html>