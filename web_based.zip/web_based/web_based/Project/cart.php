<!DOCTYPE html>
<html lang="en">
<head>
<meta charset = "UTF-8">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<title> All Products - IoT Store </title>
<link rel="stylesheet" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<?php
    include("connection.php");
    session_start();
    if(!isset($_SESSION['user'])){
            header('Location:index.php');
    }
        // print_r($_SESSION['user']); die();

    $userId=$_SESSION['user']['Customer_id'];

    if(isset($_POST['addCart'])){
        // print_r($_POST); die();
        $productId=$_POST['product_id'];
        $quantity=$_POST['quantity'];
        $sql=mysqli_query($conn,"INSERT INTO `cart`(`product_id`, `quantity`, `user_id`) 
        VALUES ('$productId','$quantity','$userId')");
            header('Location:cart.php');
    }
    if(isset($_POST['update'])){
        // print_r($_POST); die();
        $cartId=$_POST['cartId'];
        $quantity=$_POST['quantity'];
        $sql=mysqli_query($conn,"UPDATE `cart` SET `quantity`='$quantity' WHERE `id`='$cartId'");
            header('Location:cart.php');
    }
    if(isset($_GET['remove'])){
        // print_r($_POST); die();
        $cartId=$_GET['cartId'];
        $sql=mysqli_query($conn,"DELETE FROM `cart` WHERE `id`=$cartId");
            header('Location:cart.php');
    }
 
   $select = mysqli_query($conn, "SELECT cart.*,product.Product_Name,product.Product_Price,product.Product_Image FROM cart INNER JOIN product ON cart.product_id=product.Product_id where user_id=$userId");
   $cart=mysqli_fetch_all($select,MYSQLI_ASSOC);
    // print_r($cart); die();

   $latest = mysqli_query($conn, "SELECT * FROM product order by Product_id desc limit 5");
   
?>
<body>
<div class="header">


<div class ="container">
<div class ="navbar">
<div class ="logo">
<img src="images/Iot_logo.png" width="100px">

</div>

<nav>
<ul>

<li><a href="index.php">Home</a></li>
<li><a href="products.php">Products</a></li>
<li><a href="AboutUs.php">About</a></li>
<li><a href="contact.php">Contact</a></li>
 <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>

</ul>
</nav>
    <a href="cart.php"><img src="images/shoppingbag.png" width="30px" height="30px"></a>


</div>


</div>
</div>
<br>

    <!--- cart item details ---->
    
    <div class="small-container cart-page">
        
        <table>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Subtotal</th>
            </tr>
            <?php $total=0;
             foreach ($cart as $value) { $total+=$value['Product_Price']; ?>
            <tr>
                <td>
                <div class="cart-info">
                    <img src="uploaded_img/<?=$value['Product_Image']?>"width="22%">
                    <div>
                        <p><?=$value['Product_Name']?></p>
                        <small>Price: <?=$value['Product_Price']?> SAR</small>
                        <br>
                        <a  href="cart.php?remove=1&cartId=<?=$value['id']?>">Remove</a>
                    </div>
                    </div>

                </td>
                <td> 
                <form action="cart.php" method="post">
                    <input type="number" name="quantity" value="<?=$value['quantity']?>">
                    <input type="hidden" name="cartId" value="<?=$value['id']?>">
                 <input class="btn warning" style="width:80px; padding:5px" type="submit" name="update" value="update">
                 </form></td>
                <td><?=$value['Product_Price']*$value['quantity']?> SAR</td>
            </tr>
            <?php }?>
          
        </table>
        
        <div class="total-price">
            <table>
                <tr>
                    <td>Subtotal</td>
                    <td><?=$total?> SAR</td>
                </tr>
                <tr>
                    <td>Tax</td>
                    <td><?=$tax=$total*2/100?> SAR</td>
                </tr>
                <tr>
                    <td>Total</td>
                    <td><?=$tax+$total?> SAR</td>
                </tr>
            </table>
        </div>
        <a href="checkout.php" class="btn primary" style="float:right">Checkout</a>
        
    </div>
    
    
<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->

</ul>
</div>


</div></div>


    

</body>
</html>