<?php
session_start();
// if(isset($_SESSION['user'])){
// header('Location:index.php');

// }
include("connection.php");

     $username =$_POST['user'];
     $password =$_POST['pass'];
	 
	 $s = "select * from customer where username='$username' and password='$password' ";
	 $result = mysqli_query($conn, $s);
	 $count = mysqli_num_rows ($result);


	 if($count < 1){ 

		 echo '<script>
		   window.location.href ="account.php";
		   alert("Username or Password is not matched")
		   </script>';
	 }
	 else {
		$user = mysqli_fetch_assoc($result);
		$_SESSION['user']=$user;
		 echo '<script>
		   window.location.href ="index.php";
		   alert("Login Successful!")
		   </script>';
	 }
?>