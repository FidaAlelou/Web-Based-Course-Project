<?php
session_start();

include("connection.php");
$conn = mysqli_connect ('localhost','root','');
mysqli_select_db($conn,'IOT_store');

     $f_Name =$_POST['fName'];
     $l_name =$_POST['lName'];
     $username =$_POST['user1'];
	 $email =$_POST['email'];
     $password =$_POST['pass1'];
	 $phone =$_POST['phone'];
	 
	 
	 
	 $s = "select * from customer where username='$username' ";
	 $result = mysqli_query($conn, $s);
	 $count = mysqli_num_rows ($result);
	 
	 



if(isset($_POST ['submit'])){
	
	
if(empty($_POST['fName'])){
	echo '<script>
		   window.location.href ="account.php";
		   alert("Add Your First Name !!")
		   </script>';
}
else{
	$f_name = $_POST['fName'];
	
}
if(empty($_POST['lName'])){
	echo '<script>
		   window.location.href ="account.php";
		   alert("Add Your Last Name !!")
		   </script>';
}
else{
	$l_name = $_POST['lName'];
}

if(empty($_POST['user1'])){
	echo '<script>
		   window.location.href ="account.php";
		   alert("Add UserName !!")
		   </script>';
}
else{
	$username = $_POST['user1'];
}
if(empty($_POST['email'])){
	echo '<script>
		   window.location.href ="account.php";
		   alert("Add Your Email !!")
		   </script>';
}
else{
	$email = $_POST['email'];
	
}
}
if(empty($_POST['pass1'])){
	echo '<script>
		   window.location.href ="account.php";
		   alert("Add Password !!")
		   </script>';
}
else{
	$password = $_POST['pass1'];
	$uppercase    = preg_match('@[A-Z]@', $password);
    $lowercase    = preg_match('@[a-z]@', $password);
    $number       = preg_match('@[0-9]@', $password);
    $specialchars = preg_match('@[^\w]@', $password);
  
  if (!$uppercase || !$lowercase || !$number || !$specialchars || strlen($password) < 8) {
  
	echo '<script>
		   window.location.href ="account.php";
		   alert("Password is not Strong")
		   </script>';
    
  } 

}

if(empty($_POST['phone'])){
	echo '<script>
		   window.location.href ="account.php";
		   alert("Add Phone Number !!")
		   </script>';
}
else{
	$phone = $_POST['phone'];
} 



	 if($count==1){
		 
		 echo '<script>
		   window.location.href ="account.php";
		   alert("Username Alredy Taken")
		   </script>';
	 }
	 else {
		 $reg="insert into customer (First_Name , Last_Name , username ,Customer_Email ,password , phone) 
		 values ('$f_Name' ,'$l_name' ,'$username' ,'$email' ,'$password' ,'$phone')";
		 mysqli_query($conn,$reg);
		 
		 echo '<script>
		   window.location.href ="index.php";
		   alert("Registration Successful!")
		   </script>';
	 }
?>