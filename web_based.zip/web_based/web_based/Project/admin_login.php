<?php
session_start();
include("connection.php");
if(isset($_POST['submit'])){
    $username =$_POST['user'];
    $password =$_POST['pass'];
    
    $s = "select * from admin where username='$username' and password='$password' ";
    $result = mysqli_query($conn, $s);
    $count = mysqli_num_rows ($result);
    // print($count); exit;

    if($count < 1){ 

        echo '<script>
          window.location.href ="admin_login.php";
          alert("Username or Password is not matched")
          </script>';
    }
    else {
       $user = mysqli_fetch_assoc($result);
       $_SESSION['admin']=$user;
        echo '<script>
          window.location.href ="admin_page.php";
          alert("Login Successful!")
          </script>';
    } 
}

?>

<!DOCTYPE html>
<html lang="en">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<head>
<meta charset = "UTF-8">
<title> IoT Store </title>
<link rel="stylesheet" type="text/css" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body>



<div class ="container">
<div class ="navbar">
<div class ="logo">
<img src="images/Iot_logo.png" width="100px">

</div>

<nav>
<ul>

<li><a href="index.php">Home</a></li>
<li><a href="products.php">Products</a></li>
<li><a href="AboutUs.php">About</a></li>
<li><a href="contact.php">Contact</a></li>
 <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>

</ul>
</nav>
    <a href="cart.php"><img src="images/shoppingbag.png" width="30px" height="30px"></a>


</div>
</div>
<!-- account page -->

<div class="account-page">
<div class ="container">
<div class="row">
<div class ="col-2">
<img src="images/iot3.png" width="100%">
</div>

<div class ="col-2">
<div class="form-container">
<div class="form-btn">
<span >Admin Login</span> <!-- لما اضغطها راح تنفذ لي الفنكشن -->
</div>

<div id ="form" >
<form name ="LoginForm"  action= "admin_login.php"  method="POST" >
<input type="text" value="<?php if (isset($_COOKIE["user"])){echo $_COOKIE ["user"];}?>" id="user" name="user" placeholder ="Username" >

<input type="password"  value="<?php if (isset($_COOKIE["pass"])){echo $_COOKIE ["pass"];}?>" id="pass" name="pass" placeholder ="Password" >
<button type="submit" id="btn" name="submit" class ="btn"  >Login</button><br>
<?php
if(isset($_SESSION['message'])){
	echo $_SESSION ['message'];
}
unset($_SESSION['message']);
?><br>
<div class ="remb">

<label><input type ="checkbox" name ="remember" <?php if (isset($_COOKIE["user"]) && isset($_COOKIE["pass"])){echo "Checked";}?>> Remember me </label></div>
<a href ="">Forget Password</a> <!-- باقي صفحه نسيان الباسوورد -->
</form>


</div>
    
    
    
</div>
</div>
</div>
</div></div>



<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->
</ul>
</div>


</div></div>

<!-- function for Forms -->


</body>
</html>