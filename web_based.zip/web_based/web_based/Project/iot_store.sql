-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2023 at 05:24 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iot_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Admin', 'admin', 'admin@test.com', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product_id`, `quantity`, `user_id`) VALUES
(13, 2, 2, 1),
(14, 6, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(11) NOT NULL,
  `Customer_Email` varchar(50) DEFAULT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Address` varchar(150) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Phone` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `Customer_Email`, `First_Name`, `Last_Name`, `username`, `Password`, `Address`, `City`, `Phone`) VALUES
(1, 'fidaa.122@gmil.com', 'fida', 'Mohammed', 'fida_21', 'F123', NULL, NULL, 576708933),
(4, 'noor@gmail.com', 'noor', 'ali', 'noor_ali', 'noor_12@', NULL, NULL, 576708444),
(8, 'husaian@gmail.com', 'Hussain', 'Ali', 'Hussain_ali', '111', NULL, NULL, 576709986),
(10, 'May@gmail.com', 'May', 'Mohammed', 'May_11', '123', NULL, NULL, 576702222),
(11, 'Ghala@gmail.com', 'Ghala', 'Mohammed', 'Ghala_00', '111', NULL, NULL, 576703421),
(12, 'Ali11@gmail.com', 'Ali', 'Saud', 'Ali_Saud', '000', NULL, NULL, 576703422),
(15, 'Nouf_11@gmail.com', 'Nouf', 'Saad', 'Nouf_11', '111', NULL, NULL, 576702222),
(17, 'Fataimah00@gmail.com', 'Fataimah', 'Ali', 'Fataimah00', '111', NULL, NULL, 576709986),
(18, '', '', '', '', '', NULL, NULL, 0),
(20, 'Omar_22@gmail.com', 'Omar', 'H', 'Omar_H', '123', NULL, NULL, 576708933),
(22, 'maha_11@gmail.com', 'Maha', 'Saud', 'maha_11', 'JK', NULL, NULL, 576703422),
(23, 'Hind@gmail.com', 'Hind', 'Saud', 'Hind__', 'H21@Indop', NULL, NULL, 576703422),
(24, 'Hessa.12@gmail.com', 'Hessa', 'Ali', 'Hessa_21', 'H43@Iokj', NULL, NULL, 576709986),
(25, 'noor_m21@gmail.com', 'noor21', 'mohammed', 'noor_m21', 'N55@okas', NULL, NULL, 576708444),
(26, 'cylix@mailinator.com', 'Eagan Rodgers', 'Miriam Conley', 'test', 'Pa$$w0rd!', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_id` int(11) NOT NULL,
  `Order_No` int(11) NOT NULL,
  `Order_Date` datetime DEFAULT current_timestamp(),
  `Order_Total` int(11) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `delivery_address` varchar(250) NOT NULL,
  `Customer_id` int(11) DEFAULT NULL,
  `Shipping_Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Order_id`, `Order_No`, `Order_Date`, `Order_Total`, `phone`, `delivery_address`, `Customer_id`, `Shipping_Date`) VALUES
(5, 64298, '2023-02-11 20:54:50', 1301, 0, 'Clark Sparks', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `Order_Details_id` int(11) NOT NULL,
  `Product_id` int(11) DEFAULT NULL,
  `Product_Quantity` int(11) DEFAULT NULL,
  `Product_Price` int(11) DEFAULT NULL,
  `Order_id` int(11) NOT NULL,
  `Subtotal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`Order_Details_id`, `Product_id`, `Product_Quantity`, `Product_Price`, `Order_id`, `Subtotal`) VALUES
(1, 6, 1, 947, 5, 947),
(2, 1, 2, 328, 5, 656);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_id` int(11) NOT NULL,
  `Product_Name` varchar(250) DEFAULT NULL,
  `Product_Desc` varchar(250) DEFAULT NULL,
  `Product_Image` varchar(250) DEFAULT NULL,
  `Product_Price` int(11) DEFAULT NULL,
  `Rate` decimal(10,0) DEFAULT NULL,
  `Category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_id`, `Product_Name`, `Product_Desc`, `Product_Image`, `Product_Price`, `Rate`, `Category_id`) VALUES
(1, 'Test Product', '0', 'smart_lock1.jpg', 328, NULL, NULL),
(2, 'Smart Watch', '0', 'smart_watch.jpg', 115, NULL, NULL),
(6, 'Nevada Anderson', 'Nobis iure sed dolor', 'al2.png', 947, NULL, NULL),
(7, 'Fulton Morrow', 'Quos dolor laborum ', 'alarm4.jpg', 634, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `Customer_id` (`Customer_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`Order_Details_id`),
  ADD KEY `Order_id` (`Order_id`),
  ADD KEY `request_ibfk_1` (`Product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `Order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `Order_Details_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`Customer_id`) REFERENCES `customer` (`Customer_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `product` (`Product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`Order_id`) REFERENCES `orders` (`Order_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
