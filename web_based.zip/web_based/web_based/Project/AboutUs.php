<!DOCTYPE html>
<html lang="en">
<head>
<meta charset = "UTF-8">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<title> IoT Store </title>
<link rel="stylesheet" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
<div class="header">


<div class ="container">
<div class ="navbar">
<div class ="logo">
<img src="images/Iot_logo.png" width="100px">

</div>

<nav>
<ul>

<li><a href="index.php">Home</a></li>
<li><a href="products.php">Products</a></li>
<li><a href="AboutUs.php">About</a></li>
<li><a href="contact.php">Contact</a></li>
 <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>

</ul>
</nav>
    <a href="cart.php"><img src="images/shoppingbag.png" width="30px" height="30px"></a>


</div>

<section class="About">
    <div class="main">
        <img src="images/iot3.png">
        <div class="about-text">
            <h1>About Us</h1>
            <h5>Internet <span>Of Things (IoT)</span></h5>
            <p>
                Based in Saudi Arabia. We are very proud and striving to be an ever-expanding and #1 Saudi Trusted Supplier for Industrial Plug & Play Solutions covering the whole range of Industrial Internet of Things (IOT), Industrial Sensors, Wireless Sensor Network, Connected Devices, Embedded Systems, M2M, PLC, Modems and Routers, Development Boards and Kits, and Robotics.

Supplying more affordable but high-quality Industrial Plug and Play Solutions is our focus and at IOT Store, our mission is to provide the best and easy place for System Integrators, Engineers, Makers, Designers, Educators and Open Source Hardware Advocates to experience and enjoy IOT Ecosystem.

We Ship Worldwide and the shipping cost is auto-calculated in the checkout based on the shipping address and weight.

We would love to hear about adding new products to our website and offer the whole range as much as feasible and invite all to contact us.
            </p>
            <button type="button" >Let's contact</button>
        </div>
    </div>
    </section>
</div>
</div>


<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->

</ul>
</div>


</div></div>


</body>
</html>