<!DOCTYPE html>
<html lang="en">
<head>
<meta charset = "UTF-8">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<title> All Orders - IoT Store </title>
<link rel="stylesheet" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<?php
    include("connection.php");
    session_start();
    if(!isset($_SESSION['admin'])){
            header('Location:index.php');
    }
        // print_r($_SESSION['user']); die();


 
   $select = mysqli_query($conn, "SELECT * FROM orders Order by Order_id desc");
   $orders=mysqli_fetch_all($select,MYSQLI_ASSOC);
    // print_r($cart); die();

   
?>
<body>
<div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/Iot_logo.png" width="100px">

                </div>

                <nav>
                    <ul>

                        <li><a href="index.php">Home</a></li>
                        <li><a href="admin_page.php">Products</a></li>
                        <li><a href="admin_orders.php">Orders</a></li>
                        <li><a href="admin_page.php?logout=1">Logout</a></li>

                    </ul>
                </nav>
                </div>

            </div>

        </div>
   </div>
<br>

    <!--- cart item details ---->
    
    <div class="small-container cart-page">
        <h4>Recent Orders</h4> <br>
        <table>
            <tr>
                <th>Order#</th>
                <th>Order Items</th>
                <th>Sub Total</th>
                <th>Grand Total</th>
            </tr>
            <?php $total=0;
             foreach ($orders as $value) { 
                $select = mysqli_query($conn, "SELECT * FROM order_items INNER JOIN product on order_items.Product_id=product.Product_id where Order_id=$value[Order_id]");
                $items=mysqli_fetch_all($select,MYSQLI_ASSOC);
                 ?>
            <tr>
                <td><?=$value['Order_No']?></td>
                <td>
                    <?php foreach ($items as $item) {?>
                        <p><?=$item['Product_Name']?> x <?=$item['Product_Quantity']?></p>
                  <?php  } ?>
                    <div>
                </td>
                <td>   <?php $total=0; foreach ($items as $item) {$total+=$item['Product_Price']*$item['Product_Quantity']; ?>
                        <p> <?=$item['Product_Price']*$item['Product_Quantity']?> SAR</p>
                  <?php  } ?>
                </td>
                <td><?=$total?> SAR</td>
            </tr>
            <?php }?>
          
        </table>
        
        
    </div>
    
    
<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->

</ul>
</div>


</div></div>


    

</body>
</html>