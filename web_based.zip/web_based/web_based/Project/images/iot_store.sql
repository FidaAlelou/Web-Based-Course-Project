-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2023 at 03:24 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iot_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Product_id` int(11) NOT NULL,
  `Product_Price` int(11) NOT NULL,
  `Product_Image` varchar(255) NOT NULL,
  `Product_Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(11) NOT NULL,
  `Customer_Email` varchar(50) DEFAULT NULL,
  `First_Name` varchar(50) DEFAULT NULL,
  `Last_Name` varchar(50) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Address` varchar(150) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Phone` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `Customer_Email`, `First_Name`, `Last_Name`, `username`, `Password`, `Address`, `City`, `Phone`) VALUES
(1, 'fidaa.122@gmil.com', 'fida', 'Mohammed', 'fida_21', 'F123', NULL, NULL, 576708933),
(4, 'noor@gmail.com', 'noor', 'ali', 'noor_ali', 'noor_12@', NULL, NULL, 576708444),
(8, 'husaian@gmail.com', 'Hussain', 'Ali', 'Hussain_ali', '111', NULL, NULL, 576709986),
(10, 'May@gmail.com', 'May', 'Mohammed', 'May_11', '123', NULL, NULL, 576702222),
(11, 'Ghala@gmail.com', 'Ghala', 'Mohammed', 'Ghala_00', '111', NULL, NULL, 576703421),
(12, 'Ali11@gmail.com', 'Ali', 'Saud', 'Ali_Saud', '000', NULL, NULL, 576703422),
(15, 'Nouf_11@gmail.com', 'Nouf', 'Saad', 'Nouf_11', '111', NULL, NULL, 576702222),
(17, 'Fataimah00@gmail.com', 'Fataimah', 'Ali', 'Fataimah00', '111', NULL, NULL, 576709986),
(18, '', '', '', '', '', NULL, NULL, 0),
(20, 'Omar_22@gmail.com', 'Omar', 'H', 'Omar_H', '123', NULL, NULL, 576708933),
(22, 'maha_11@gmail.com', 'Maha', 'Saud', 'maha_11', 'JK', NULL, NULL, 576703422),
(23, 'Hind@gmail.com', 'Hind', 'Saud', 'Hind__', 'H21@Indop', NULL, NULL, 576703422),
(24, 'Hessa.12@gmail.com', 'Hessa', 'Ali', 'Hessa_21', 'H43@Iokj', NULL, NULL, 576709986),
(25, 'noor_m21@gmail.com', 'noor21', 'mohammed', 'noor_m21', 'N55@okas', NULL, NULL, 576708444);

-- --------------------------------------------------------

--
-- Table structure for table `order_`
--

CREATE TABLE `order_` (
  `Order_id` varchar(50) NOT NULL,
  `Order_No` int(11) NOT NULL,
  `Order_Date` datetime DEFAULT NULL,
  `Order_Total` int(11) DEFAULT NULL,
  `Customer_id` int(11) DEFAULT NULL,
  `Shipping_Date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_id` int(11) NOT NULL,
  `Product_Name` int(50) DEFAULT NULL,
  `Product_Desc` int(150) DEFAULT NULL,
  `Image1` int(50) DEFAULT NULL,
  `Price` int(11) DEFAULT NULL,
  `Rate` decimal(10,0) DEFAULT NULL,
  `Category_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE `request` (
  `Order_Details_id` int(11) NOT NULL,
  `Product_id` int(11) DEFAULT NULL,
  `Product_Quantity` int(11) DEFAULT NULL,
  `Product_Price` int(11) DEFAULT NULL,
  `Order_id` varchar(50) NOT NULL,
  `Subtotal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Product_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `order_`
--
ALTER TABLE `order_`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `Customer_id` (`Customer_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`Order_Details_id`),
  ADD KEY `Product_id` (`Product_id`),
  ADD KEY `Order_id` (`Order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Product_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_`
--
ALTER TABLE `order_`
  ADD CONSTRAINT `order__ibfk_1` FOREIGN KEY (`Customer_id`) REFERENCES `customer` (`Customer_id`);

--
-- Constraints for table `request`
--
ALTER TABLE `request`
  ADD CONSTRAINT `request_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `product` (`Product_id`),
  ADD CONSTRAINT `request_ibfk_2` FOREIGN KEY (`Order_id`) REFERENCES `order_` (`Order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
