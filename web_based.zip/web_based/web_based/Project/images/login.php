<?php


if(isset($_POST ['submit'])){
	session_start();
	include("connection.php");
	 $username =$_POST['user'];
     $password =$_POST['pass'];
	 
	 $sql ="select * from customer where username='$username' and password='$password'";
	 $result = mysqli_query($conn,$sql);
	
	 if($username =="admin"&& $password="A@dmin-760"){
		 header("Location:admin_page.php");
	 }
	 if(mysqli_num_rows($result) == 0){
		 $_SESSION['message']= "Log in Faild. User or Password invalid";
		  header("Location:account.php");
	 }
	 else{
		  $row = mysqli_fetch_array($result);
		  if(isset($_POST['remember'])){
			  setcookie("user",$row['username'], time() +(86400 * 30));
			  setcookie("pass",$row['password'], time() +(86400 * 30));
		  }
		  $_SESSION['id']= $row['customer_id'];
		  header('Location :success.php');
	 }
	  
}
?>