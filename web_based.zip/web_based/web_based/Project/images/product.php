<?php
include("connection.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset = "UTF-8">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<title> All Products - IoT Store </title>
<link rel="stylesheet" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
<div class="header">


<div class ="container">
<div class ="navbar">
<div class ="logo">
<img src="Iot_logo.png" width="100px">

</div>

<nav>
<ul>

<li><a href="index.php">Home</a></li>
<li><a href="products.php">Products</a></li>
<li><a href="AboutUs.php">About</a></li>
<li><a href="contact.php">Contact</a></li>
 <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>

</ul>
</nav>
    <a href="cart.php"><img src="shoppingbag.png" width="30px" height="30px"></a>

<div class="search">
<input type="text" class="search-box" placeholder="search product">
<button class="search-btn">search</button>
</div>

</div>


</div>
</div>

<!-- Featured products -->
<div class="small-container">
    <div class="row row-2">
        <h2>All Prodocts</h2>
         <select>
            <option>Sort by price</option>
            <option>Sort by popularity</option>
            <option>Sort by rating</option>
             <option>Sort by sale</option>
        </select>
    </div>
<div class ="row">

<div class ="col-4">
<img src="cam2.jpg">
    <h4><a href="product-details1.html">Solar-Powered Security Camera</a></h4>
<div class="rating">
<i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</div>
<p>632.50 SAR</p>
</div>

<div class ="col-4">
<img src="smart_lock2.jpg">
<h4><a href="product-details3.html">Fingerprint Smart Door Lock</a></h4>
<div class="rating">
<i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star-o"></i>
</div>
<p>329 SAR</p>
</div>

<div class ="col-4">
<img src="alexa2.jpg">
<h4> <a href="product-details6.html">Smart speaker with Alexa</a></h4>
<div class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star-o"></i>
<i class="fa fa-star-o"></i>
</div>
<p>270 SAR</p>
</div>

<div class ="col-4">
<img src="smart_watch.jpg">
<h4> <a href="product-details5.html">Smartwatch Full-Touch </a> </h4>
<div class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</div>
<p>990 SAR</p>
</div>
</div>

<div class ="row">

<div class ="col-4">
<img src="lock1.jpg">
<h4><a href="product-details.html">Biometric Fingerprint Lock, App Password Door Lock</a></h4>
<div class="rating">
<i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star-o"></i>
<i class="fa fa-star-o"></i>
</div>
<p>470 SAR</p>
</div>

<div class ="col-4">
<img src="alexa3.jpg">
<h4><a href="product-details4.html">Smart speaker with Alexa (Arabic or English) </a></h4>
<div class="rating">
<i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star-half-o"></i>
<i class="fa fa-star-o"></i>
</div>
<p>1200 SAR</p>
</div>

<div class ="col-4">
<img src="smart_watch2.jpg">
<h4> <a href="product-details7.html">Fitbit Sense Smartwatch</a> </h4>
<div class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star-o"></i>
<i class="fa fa-star-o"></i>
</div>
<p>1560 SAR</p>
</div>

<div class ="col-4">
<img src="alarm_System.png">
<h4> <a href="product-details8.html">Alarm Systems Touch Screen ,Tuya Smart System Home Security</a> </h4>
<div class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
</div>
<p>330 SAR</p>
</div>

<div class ="col-4">
<img src="dashcam.jpg">
<h4> <a href="product-details9.html">Dash Cam with 1080p HD - Front and Rear Camera </a></h4>
<div class="rating">
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star"></i>
<i class="fa fa-star-o"></i>
</div>
<p>234.60 SAR</p>
</div>



</div>
   <!-- New Prouduct -->
 <div class="New-Product"> 
     <h3><center>New Product</center></h3>
     <?php

   $select = mysqli_query($conn, "SELECT * FROM Admin");
   
   ?>
   <div class="product-display">
      <table class="product-display-table">
         <thead>
         <tr>
            <th>product image</th>
             <th>product name</th>
            <th>product price</th>
    
         </tr>
         </thead>
         <?php while($row = mysqli_fetch_assoc($select)){ ?>
         <tr>
            <td><img src="Project/uploaded_img/<?php echo $row['Product_Image']; ?>" height="100" alt=""></td>
             <td><a href="product-detailsF.php"><?php echo $row['Product_Name']; ?></a></td>
              
             
            <td>$<?php echo $row['Product_Price']; ?>/-</td>
           
         </tr>
      <?php } ?>
      </table>
   </div>

    </div>
 
</div>


    
<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->

</ul>
</div>


</div></div>


</body>
</html>