<!DOCTYPE html>
<html lang="en">
<meta name ="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
<head>
<meta charset = "UTF-8">
<title> All Products - IoT Store </title>
<link rel="stylesheet" href ="style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
<div class="header">
<?php
    include("connection.php");

   $sql = mysqli_query($conn, "SELECT * FROM product where Product_id='$_GET[id]'");
   $product=mysqli_fetch_assoc($sql);
//    print_r($product); exit;
   $latest = mysqli_query($conn, "SELECT * FROM product order by Product_id desc limit 5");
   
?>

<div class ="container">
<div class ="navbar">
<div class ="logo">
<img src="images/Iot_logo.png" width="100px">

</div>

<nav>
<ul>

<li><a href="index.php">Home</a></li>
<li><a href="products.php">Products</a></li>
<li><a href="AboutUs.php">About</a></li>
<li><a href="contact.php">Contact</a></li>
 <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>

</ul>
</nav>
    <a href="cart.php"><img src="images/shoppingbag.png" width="30px" height="30px"></a>

</div>


</div>
</div>
<br>
<!-- Single product details -->
    <div class="small-container single-product">
        <div class="row">
            <div class="col-2">
                <img src="uploaded_img/<?=$product['Product_Image']?>" width="90%" id="productImg">
                <div class="small-img-row">
                    <!-- <div class="small-img-col">
                        <img src="images/lock2.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/lock3.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/lock4.png" width="100%" class="small-img">
                    </div>
                    <div class="small-img-col">
                        <img src="images/lock5.png" width="100%" class="small-img">
                    </div> -->
                </div>
            </div>
            <div class="col-2">
                <!-- <p><?=$product['Product_Name']?></p> -->
                <h1><?=$product['Product_Name']?></h1>
                <h4><?=$product['Product_Price']?> SAR</h4>
                <form action="cart.php" method="post" >
                    <input type="number" name="quantity" value="1">
                    <input type="hidden" name="product_id" value="<?=$_GET['id']?>">
                    <input type="submit" name="addCart" value="Add To cart" class="btn" style="width:180px">
                </form>
                <h3>Product Details <i class="fa fa-indent"></i></h3>
                <br>
                <p><?=$product['Product_Desc']?></p>
            </div>
        </div>
    </div>
    
    
    <!---title----->
    
    <div class="small-container">
        <div class="row row-2">
            <h2>Related Products</h2>
            <p><a href="products.php">View more</a> </p>
        </div>
    </div>
    
    
    <!----product---->
    
    
<div class="small-container">
<div class ="row">

<?php while($row = mysqli_fetch_assoc($latest)){  ?>
<div class ="col-4">
    <a href="product-details.php?id=<?=$row['Product_id']?>">
        <img src="uploaded_img/<?=$row['Product_Image']?>">
        <h4><?=$row['Product_Name']?></h4>
        <div class="rating">
        <i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        </div>
        <p><?=$row['Product_Price']?> SAR</p>
    </a>
</div>
<?php }?>


</div>

</div>
   



<!-- footer -->
<div class="footer">
<div class ="container">
<div class="row">
<p>Connect With us</p>
</div>
<div class="row">

<ul class="social-links">
<li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li> <!-- رابط الانستقرام -->
<li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li><!-- رابط الايميل -->

</ul>
</div>


</div></div>

    <!---js for product gallery ----->
    <script>
        var productImg = document.getElementById("productImg")
        var smallImg = document.getElementsByClassName("small-img")
        
        smallImg[0].onclick = function(){
            productImg.src = smallImg[0].src;
        }
        smallImg[1].onclick = function(){
            productImg.src = smallImg[2].src;
        }
        smallImg[2].onclick = function(){
            productImg.src = smallImg[2].src;
        }
        smallImg[3].onclick = function(){
            productImg.src = smallImg[3].src;
        }
        
    </script>
    

</body>
</html>