<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="keywords" content="Iot, smart watch,Security Camera,smart device,Smart Door Lock ,fingerprint lock
Alarm System,Dash Cam ,Vacuum , Alexa,Smart speaker">
    <title> IoT Store </title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
    <?php
    include("connection.php");
    session_start();
    if(isset($_GET['logout'])){
        unset($_SESSION['user']);
           header('Location:index.php');
     }
   $select = mysqli_query($conn, "SELECT * FROM product limit 5");
   $latest = mysqli_query($conn, "SELECT * FROM product order by Product_id desc limit 5");
   
?>
    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/Iot_logo.png" width="100px">

                </div>

                <nav>
                    <ul>

                        <li><a href="index.php">Home</a></li>
                        <li><a href="products.php">Products</a></li>
                        <li><a href="AboutUs.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                          <?php if(isset($_SESSION['user'])){?>
                            <li><a href="orders.php">My Orders</a></li>
                            <li><a href="index.php?logout=1">Logout</a></li>

                        <?php }else{ ?>
                            <li><a href="account.php">Account</a></li>
                       <?php } ?>
                       

                    </ul>
                </nav>
                <a href="cart.php"><img src="images/shoppingbag.png" width="30px" height="30px"></a>
        

            </div>

            <div class="row">
                <div class="col-2">
                    <h1> Let your life <br>be full of new technology! </h1>

                    <p>Life is not entirely dependent on technology,
                        but the Internet of Things<br>
                        will improve the efficiency of products and enhance the quality of life. </p>
                    <a href="products.php" class="btn">Explore Now &#8594;</a>
                </div>
                <div class="col-2">
                    <img src="images/iot3.png">

                </div>
            </div>
        </div>
    </div>

    <!-- best categories -->

    <div class="bestCategories">

        <div class="small-container">
            <div class="row">
                <div class="col-3">
                    <img src="images/smart_lock1.jpg">
                </div>
                <div class="col-3">
                    <img src="images/cam.jpg">
                </div>
                <div class="col-3">
                    <img src="images/alexa.jpg">
                </div>
            </div>
        </div>
    </div>

    <!-- Featured products -->
    <div class="small-container">
        <h2 class="title">Featured Products </h2>
        <div class="row">
            <?php while($row = mysqli_fetch_assoc($select)){  ?>
            <div class="col-4">
                <a href="product-details.php?id=<?=$row['Product_id']?>">
                    <img src="uploaded_img/<?=$row['Product_Image']?>">
                    <h4>
                        <?=$row['Product_Name']?>
                    </h4>
                    <div class="rating">
                        <i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>
                        <?=$row['Product_Price']?> SAR
                    </p>
                </a>
            </div>
            <?php }?>


        </div>

        <h2 class="title">Latest Products </h2>
        <div class="row">

            <?php while($row = mysqli_fetch_assoc($latest)){  ?>
            <div class="col-4">
                <a href="product-details.php?id=<?=$row['Product_id']?>">
                    <img src="uploaded_img/<?=$row['Product_Image']?>">
                    <h4>
                        <?=$row['Product_Name']?>
                    </h4>
                    <div class="rating">
                        <i class="fa fa-star"></i><!-- يطلع لي الستار حق الريتنق , جاهزه من النت -->
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <p>
                        <?=$row['Product_Price']?> SAR
                    </p>
                </a>
            </div>
            <?php }?>


        </div>
    </div>

    <!-- offer -->
    <div class="offer">
        <div class="small-container">
            <div class="row">
                <div class="col-2">
                    <img src="images/Ecovacs.png" class="offer-img">
                </div>
                <div class="col-2">
                    <p>Exculsively Available on IoT Store
                    <p>
                    <h1>ECOVACS Robot Vacuum Cleaner </h1>
                    <small> 2-in-1 Vacuuming & Mopping with Smart Navi 3.0 Laser Technology,
                        Multi-floor Mapping,Virtual Wall, Works on Carpets & Hard Floors</small>
                    <br>
                    <a href="product-details2.html" class="btn">Buy Now &#8594;</a> <!-- #8594 for the row icon -->
                </div>
            </div>
        </div>
    </div>

    <!-- reviews -->
    <div class="reviews">
        <div class="small-container">
            <div class="row">
                <div class="col-3">
                    <i class="fa fa-quote-left"></i> <!-- ايقونه الاقتباس جاهزه من النت -->
                    <p>I have dealt with this store many times, they have speed of delivery and the quality of the
                        products is great </p>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>
                    </div>
                    <img src="images/m-user.png">
                    <h3>Ali Ahmad</h3>
                </div>

                <div class="col-3">
                    <i class="fa fa-quote-left"></i> <!-- ايقونه الاقتباس جاهزه من النت -->
                    <p>Very nice store and their prices are suitable for the market, I will buy again soon ...</p>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                    </div>
                    <img src="images/w-user.jpg">
                    <h3>Norah Mohammed</h3>
                </div>


                <div class="col-3">
                    <i class="fa fa-quote-left"></i> <!-- ايقونه الاقتباس جاهزه من النت -->
                    <p>I have bought a protection system and it is very useful and its quality is high I recommend
                        dealing with this store</p>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                    </div>
                    <img src="images/w-user.jpg">
                    <h3>Asma Fahad</h3>
                </div>

            </div>
        </div>
    </div>

    <!-- footer -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <p>Connect With us</p>
            </div>
            <div class="row">

                <ul class="social-links">
                    <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                    <!-- رابط الانستقرام -->
                    <li><a href="mailto: iotstore.2023@gmail.com"> <i class="fa fa-envelope"></i></a></li>
                    <!-- رابط الايميل -->

                </ul>
            </div>


        </div>
    </div>


</body>

</html>